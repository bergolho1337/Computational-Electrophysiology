#!/bin/bash
cd vtk; rm *

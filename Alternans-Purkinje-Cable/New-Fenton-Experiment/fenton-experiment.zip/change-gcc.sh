#!/bin/bash

export CC=/usr/bin/gcc53
export CXX=/usr/bin/g++53


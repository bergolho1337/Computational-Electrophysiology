#define INITIAL_SIZE (8)
#define GROWTH_FACTOR (2)
#define MAX_LOAD_FACTOR (1)
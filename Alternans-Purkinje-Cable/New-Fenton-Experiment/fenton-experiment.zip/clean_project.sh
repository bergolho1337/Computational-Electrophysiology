#!/bin/bash
cd build; rm -r *; cd ..
cd bin; rm *

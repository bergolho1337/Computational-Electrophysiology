#!/bin/bash
cd vtk; rm *; cd ..
cd output; rm *
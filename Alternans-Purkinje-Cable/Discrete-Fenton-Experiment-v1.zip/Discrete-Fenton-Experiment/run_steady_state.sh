#!/bin/bash

echo "******************** STEADY STATE SIMULATION **********************************"
./purkinje -t 0.1 6600 Meshes/cable5cm-dog.msh teste.sst Plot/cable5cm-dog.plt
echo "******************** STEADY STATE SIMULATION **********************************"